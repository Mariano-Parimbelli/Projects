function loadFurnitureCards() {
    fetch('data/muebles.json')
        .then(response => response.json())
        .then(data => {
            console.log('Furniture data:', data); // Verifica los datos
            const content = document.getElementById('content');
            if (content) {
                content.innerHTML = '';
                data.forEach(mueble => {
                    const card = document.createElement('div');
                    card.className = 'card';

                    const cardLink = document.createElement('a');
                    cardLink.href = `mueble.html?id=${mueble.id}`;
                    cardLink.className = 'card-link';

                    const img = document.createElement('img');
                    img.src = mueble.image;
                    img.alt = mueble.title;
                    img.className = 'card-img';

                    const title = document.createElement('div');
                    title.className = 'card-title';
                    title.textContent = mueble.title;

                    const price = document.createElement('div');
                    price.className = 'card-price';
                    price.textContent = mueble.price;

                    const description = document.createElement('div');
                    description.className = 'card-description';
                    description.textContent = mueble.description;

                    cardLink.appendChild(img);
                    cardLink.appendChild(title);
                    cardLink.appendChild(price);
                    cardLink.appendChild(description);

                    card.appendChild(cardLink);
                    content.appendChild(card);
                });
            } else {
                console.warn('Content element not found');
            }
        })
        .catch(error => console.error('Error loading the JSON file:', error));
}

function loadFurnitureDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const muebleId = urlParams.get('id');

    fetch('data/muebles.json')
        .then(response => response.json())
        .then(data => {
            const mueble = data.find(item => item.id === muebleId);

            if (mueble) {
                const content = document.getElementById('content');
                if (content) {
                    content.innerHTML = `
                        <div class="mueble-detail">
                            <h2 class="mueble-title">${mueble.title}</h2>
                            <img src="${mueble.image}" alt="${mueble.title}" class="mueble-img">
                            <div class="mueble-info">
                                <div class="mueble-price">${mueble.price}</div>
                                <div class="mueble-description">${mueble.description}</div>
                                <a href="https://wa.me/+543544535720?text=Hola%21%20Queria%20consultar%20sobre%20este%20mueble%3A%20${encodeURIComponent(window.location.href)}" class="ask-button">Preguntar por el mueble</a>
                            </div>
                        </div>
                    `;
                } else {
                    console.warn('Content element not found');
                }
            } else {
                document.getElementById('content').innerHTML = '<p>Mueble no encontrado.</p>';
            }
        })
        .catch(error => console.error('Error loading the JSON file:', error));
}

function navigateTo(page) {
    const content = document.getElementById('content');
    const videoBanner = document.getElementById('video-banner');

    if (videoBanner) {
        if (page === 'mediosdepago' || page === 'contacto') {
            videoBanner.style.display = 'none'; // Ocultar el banner en estas páginas
        } else {
            videoBanner.style.display = 'block'; // Mostrar el banner en otras páginas
        }
    } else {
        console.warn('video-banner element not found');
    }

    if (page === 'mediosdepago') {
        if (content) {
            content.innerHTML = `
                <div style="max-width: 90%; margin: 75px auto 0; background-color: transparent; padding: 0 7px; overflow: hidden;">
                    <video autoplay loop muted playsinline style="width: 100%; height: auto; max-height: 80vh; display: block; background-color: transparent; border-radius: 15px;" loading="lazy">
                        <source src="assets/metodosPago.webm" type="video/webm">
                        Tu navegador no soporta el formato de vídeo WebM.
                    </video>
                </div>
            `;
        } else {
            console.warn('Content element not found');
        }
    } else if (page === 'contacto') {
        if (content) {
            content.innerHTML = `
                <div style="display: flex; flex-direction: column; align-items: center;">
                    <h2 style="color: #fff; margin-bottom: 10px; margin-top: 70px; font-size: 24px;">Contacto</h2>
                    <a href="https://wa.me/+543544535720" target="_blank" style="text-decoration: none;">
                        <div class="contact-card" style="width: 335px; height: 90px; display: flex; align-items: center; justify-content: center; border: 0.8px solid #fff; padding: 5px; margin-bottom: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);">
                            <img src="assets/WhatsApp_icon.png" alt="WhatsApp" style="width: 39px; margin-right: 10px;" loading="lazy">
                            <span style="color: #fff;">WhatsApp</span>
                        </div>
                    </a>

                    <a href="https://www.google.com.ar/maps/place/C.+Combatientes+de+Islas+Malvinas,+X5889,+C%C3%B3rdoba/@-31.7459313,-65.0015255,20z/data=!4m6!3m5!1s0x942d260628302bb5:0x6789e5093c5b3a34!8m2!3d-31.7458309!4d-65.0012559!16s%2Fg%2F11fpgfsqnh?entry=ttu&g_ep=EgoyMDI0MDkwMi4xIKXMDSoASAFQAw%3D%3D" target="_blank" style="text-decoration: none;">
                        <div class="contact-card" style="width: 335px; height: 95px; display: flex; align-items: center; justify-content: center; border: 0.8px solid #fff; padding: 5px; margin-bottom: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);">
                            <img src="https://static.vecteezy.com/system/resources/previews/014/203/842/non_2x/locator-mark-of-map-and-location-pin-on-transparent-background-free-png.png" alt="Ubicación" style="width: 69px; margin-right: 10px;" loading="lazy">
                            <span style="font-size: 22px; color: #fff; text-align: center;">Combatientes de Malvinas 2880, Mina Clavero Cordoba</span>
                        </div>
                    </a>

                    <a href="mailto:mariasolparimbelli@gmail.com" target="_blank" style="text-decoration: none;">
                        <div class="contact-card" style="width: 335px; height: 95px; display: flex; align-items: center; justify-content: center; border: 0.8px solid #fff; padding: 5px; margin-bottom: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);">
                            <img src="assets/Gmail_Icon.png" alt="Email" style="width: 39px; margin-right: 10px;" loading="lazy">
                            <span style="color: #fff;">Email</span>
                        </div>
                    </a>
                    <a href="https://www.instagram.com" target="_blank" style="text-decoration: none;">
                        <div class="contact-card" style="width: 335px; height: 95px; display: flex; align-items: center; justify-content: center; border: 0.8px solid #fff; padding: 5px; margin-bottom: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);">
                            <img src="assets/Instagram_icon.png" alt="Instagram" style="width: 39px; margin-right: 10px;" loading="lazy">
                            <span style="color: #fff;">Instagram</span>
                        </div>
                    </a>
                    <a href="https://www.tiktok.com/@tomy.saavedra" target="_blank" style="text-decoration: none;">
                        <div class="contact-card" style="width: 335px; height: 95px; display: flex; align-items: center; justify-content: center; border: 0.8px solid #fff; padding: 5px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);">
                            <img src="assets/tiktok.png" alt="TikTok" style="width: 39px; margin-right: 10px;" loading="lazy">
                            <span style="color: #fff;">TikTok</span>
                        </div>
                    </a>
                </div>
            `;
        } else {
            console.warn('Content element not found');
        }
    } else if (page === 'home' || page === '/') {
        loadFurnitureCards();
    } else {
        if (content) {
            content.innerHTML = '<p>Sección no encontrada.</p>';
        } else {
            console.warn('Content element not found');
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const path = window.location.pathname;
    if (path.includes('mueble.html')) {
        loadFurnitureDetail();
    } else if (path === '/' || path === '' || path.includes('index.html')) {
        navigateTo('home');
    } else {
        const page = document.body.dataset.page || 'home';
        navigateTo(page);
    }

    const homeButton = document.querySelector('button[onclick*="navigateTo(\'home\')"]');
    if (homeButton) {
        homeButton.addEventListener('click', () => {
            window.location.href = '/'; // Redirigir a la página raíz
        });
    } else {
        console.warn('homeButton element not found');
    }
});
// Función para desplazar la página hacia abajo
function scrollDown() {
    window.scrollBy({
        top: window.innerHeight, // Desplazar hacia abajo una altura de la ventana
        behavior: 'smooth' // Desplazamiento suave
    });
}